package misclases;

public class Administrador extends Persona {

	public Administrador(String nombre, String apellido, String dni,
			String domicilio, String email, String sexo, String fechaNacimiento) {
		super(nombre, apellido, dni, domicilio, email, sexo, fechaNacimiento);
		// TODO Auto-generated constructor stub
	}

}
