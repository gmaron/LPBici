package misclases;

public class Usuario extends Persona{

	boolean habilitado;
	
	public Usuario(String nombre, String apellido, String email,
			String dni, String domicilio, String sexo, String fechaNacimiento) {
		super(nombre, apellido, email, dni, domicilio, sexo, fechaNacimiento);
		// TODO Auto-generated constructor stub
		habilitado = true;
	}

	public boolean isHabilitado() {
		return habilitado;
	}

	public void setHabilitado(boolean habilitado) {
		this.habilitado = habilitado;
	} 
	
	
	
}
