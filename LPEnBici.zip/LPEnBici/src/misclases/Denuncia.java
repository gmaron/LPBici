package misclases;

public class Denuncia {
	private Usuario usuarioDenuncia;
	private String comentario; //el comentario puede venir vacio
	
		
	public Denuncia(Usuario usuarioDenuncia, String comentario) {
		super();
		this.usuarioDenuncia = usuarioDenuncia;
		this.comentario = comentario;
	}
	
	public Usuario getUsuarioDenuncia() {
		return usuarioDenuncia;
	}
	public void setUsuarioDenuncia(Usuario usuarioDenuncia) {
		this.usuarioDenuncia = usuarioDenuncia;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	
	

}
